# music-imooc 从0打造云音乐全栈小程序
开发步骤详细记录在从*0打造云音乐全栈小程序.docx*文档里。

有道云链接：http://note.youdao.com/noteshare?id=6993c60fd1105af2ded2c3cdc0a1c8ee

#### 文件介绍：
**music-imooc**：小程序端的代码

**music-imooc-admin-backend**：管理后台的后台代码

**music-imooc-admin-frontend**：管理后台的前台代码
#### 小程序的页面截图：
![Image](https://github.com/xieshuangting/music-imooc/blob/master/mdImages/1.png)
![Image](https://github.com/xieshuangting/music-imooc/blob/master/mdImages/2.png)
![Image](https://github.com/xieshuangting/music-imooc/blob/master/mdImages/3.png)
![Image](https://github.com/xieshuangting/music-imooc/blob/master/mdImages/4.png)
![Image](https://github.com/xieshuangting/music-imooc/blob/master/mdImages/5.png)
![Image](https://github.com/xieshuangting/music-imooc/blob/master/mdImages/6.png)
![Image](https://github.com/xieshuangting/music-imooc/blob/master/mdImages/7.png)
![Image](https://github.com/xieshuangting/music-imooc/blob/master/mdImages/8.png)
![Image](https://github.com/xieshuangting/music-imooc/blob/master/mdImages/9.png)
![Image](https://github.com/xieshuangting/music-imooc/blob/master/mdImages/10.png)
![Image](https://github.com/xieshuangting/music-imooc/blob/master/mdImages/11.png)
![Image](https://github.com/xieshuangting/music-imooc/blob/master/mdImages/12.png)
